import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Certifications from './components/Certifications';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="bg-slate-950 text-slate-300 font-sans leading-relaxed">
      <Header />
      <main>
        <Hero />
        <div id="about" className="bg-slate-950 py-16 md:py-24">
            <About />
        </div>
        <div id="skills" className="bg-slate-900 py-16 md:py-24">
            <Skills />
        </div>
        <div id="experience" className="bg-slate-950 py-16 md:py-24">
            <Experience />
        </div>
        <div id="projects" className="bg-slate-900 py-16 md:py-24">
            <Projects />
        </div>
        <div id="certifications" className="bg-slate-950 py-16 md:py-24">
            <Certifications />
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;