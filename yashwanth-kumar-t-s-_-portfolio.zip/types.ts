
export interface Skill {
  name: string;
  category: string;
}

export interface Project {
  title: string;
  date: string;
  description: string[];
  tech: string[];
}

export interface TimelineEvent {
  date: string;
  title: string;
  subtitle: string;
  description: string;
  type: 'education' | 'internship';
}

export interface Certification {
    name: string;
    issuer: string;
    date: string;
}
