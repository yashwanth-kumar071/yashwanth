
import type { Skill, Project, TimelineEvent, Certification } from './types';

export const PERSONAL_INFO = {
  name: "Yashwanth Kumar T S",
  title: "Aspiring Software Developer",
  objective: "As a motivated Computer Science student with strong problem-solving skills, I am seeking a position within a dynamic organization. My goal is to contribute meaningfully to the company's success while expanding my technical and professional skillset in a collaborative and growth-oriented environment.",
  contact: {
    email: "yashwanthyk600@gmail.com",
    phone: "+91 7338442338",
    linkedin: "https://www.linkedin.com/in/yashwanth-kumarts",
  },
};

export const SKILLS: Skill[] = [
  { name: 'Java', category: 'Programming Languages' },
  { name: 'HTML', category: 'Web Technologies' },
  { name: 'CSS', category: 'Web Technologies' },
  { name: 'SQL', category: 'Database' },
  { name: 'Object-Oriented Programming', category: 'Concepts' },
  { name: 'Data Structures', category: 'Concepts' },
  { name: 'Machine Learning', category: 'Concepts' },
  { name: 'Python', category: 'Programming Languages' },
  { name: 'Project Management', category: 'Soft Skills' },
  { name: 'Time Management', category: 'Soft Skills' },
  { name: 'Adaptability', category: 'Soft Skills' },
  { name: 'Communication', category: 'Soft Skills' },
];

export const PROJECTS: Project[] = [
  {
    title: 'Food Ordering System',
    date: 'Sep 2024',
    description: [
      'Developed a scalable SQL database to manage orders, inventory, and customer preferences.',
      'Implemented real-time data processing using Java for order tracking.',
      'Integrated a user-friendly interface to enhance customer experience.'
    ],
    tech: ['Java', 'SQL', 'UI/UX Design']
  },
  {
    title: 'IoT Based Fall Detection System',
    date: 'June 2024',
    description: [
      'Developed an IoT-based system using accelerometers and gyroscopes to monitor for falls in real-time.',
      'The system immediately sends an SMS alert to designated caregivers or medical authorities upon detecting a fall.'
    ],
    tech: ['IoT', 'Sensors', 'Real-time Alerts']
  },
  {
    title: 'Breast Cancer Type Prediction',
    date: 'June 2024',
    description: [
      'Built a model using logistic regression to predict breast cancer types from clinical and pathological data.',
      'Aims to enhance diagnostic accuracy and support personalized treatment plans.'
    ],
    tech: ['Machine Learning', 'Python', 'Logistic Regression']
  }
];

export const TIMELINE: TimelineEvent[] = [
  {
    date: 'Dec 2021 - Aug 2025',
    title: 'Sapthagiri College Of Engineering',
    subtitle: 'B.E in Computer Science (CGPA: 7.29/10)',
    description: 'Bengaluru, India',
    type: 'education',
  },
  {
    date: 'Ongoing Internship',
    title: 'Machine Learning Intern',
    subtitle: 'Karunadu Technologies Pvt Ltd',
    description: 'Implemented supervised learning algorithms for data analysis. Worked on data preprocessing and feature selection for improved model accuracy.',
    type: 'internship',
  },
  {
    date: 'Feb 2020 - Mar 2021',
    title: 'Arvind PU College',
    subtitle: 'Pre-University Education (Grade: 81%)',
    description: 'Tumakuru, India',
    type: 'education',
  },
  {
    date: 'May 2018 - Jun 2019',
    title: 'Pushpagiri High School',
    subtitle: 'Secondary Education (Grade: 86.08%)',
    description: 'Mandya, India',
    type: 'education',
  }
];


export const CERTIFICATIONS: Certification[] = [
    {
        name: 'Programming in Java',
        issuer: 'Great Learning Academy',
        date: 'Aug 2024'
    }
];
