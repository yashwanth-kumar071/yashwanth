import React from 'react';
import { PERSONAL_INFO } from '../constants';

const Hero: React.FC = () => {
  const handleCTAClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center text-center px-6 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900 to-slate-950">
      <div className="opacity-0 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold text-slate-100 tracking-tight">
          {PERSONAL_INFO.name}
        </h1>
        <h2 className="mt-4 text-2xl md:text-3xl lg:text-4xl font-semibold text-cyan-400">
          {PERSONAL_INFO.title}
        </h2>
        <p className="mt-6 max-w-2xl mx-auto text-lg text-slate-400">
          A passionate computer science student dedicated to building innovative solutions and growing in a collaborative environment.
        </p>
        <div className="mt-10">
           <a 
            href="#projects" 
            onClick={handleCTAClick}
            className="bg-cyan-500 text-slate-900 font-bold py-3 px-8 rounded-full text-lg hover:bg-cyan-400 transition-all duration-300 transform hover:scale-105"
            >
            View My Work
          </a>
        </div>
      </div>
    </div>
  );
};

export default Hero;