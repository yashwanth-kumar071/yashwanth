import React from 'react';
import { CERTIFICATIONS } from '../constants';
import SectionHeader from './SectionHeader';

const Certifications: React.FC = () => {
  return (
    <div className="container mx-auto px-6 md:px-12 lg:px-24 opacity-0 animate-fade-in-up">
      <SectionHeader title="Certifications" />
      <div className="max-w-2xl mx-auto">
        {CERTIFICATIONS.map((cert, index) => (
          <div key={index} className="bg-slate-800 rounded-lg p-6 text-center border border-slate-700 shadow-lg">
            <p className="text-xs text-cyan-400 font-mono">{cert.date}</p>
            <h3 className="text-xl font-bold text-slate-100 mt-2">{cert.name}</h3>
            <p className="text-slate-400 mt-1">Issued by <span className="font-semibold text-slate-300">{cert.issuer}</span></p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Certifications;