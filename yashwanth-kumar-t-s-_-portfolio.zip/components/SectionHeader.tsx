import React from 'react';

interface SectionHeaderProps {
  title: string;
}

const SectionHeader: React.FC<SectionHeaderProps> = ({ title }) => {
  return (
    <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-slate-100">
            {title}
        </h2>
        <div className="w-24 h-1 bg-cyan-400 mx-auto mt-4 rounded"></div>
    </div>
  );
};

export default SectionHeader;