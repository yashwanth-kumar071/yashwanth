import React from 'react';
import { PERSONAL_INFO } from '../constants';
import { MailIcon, LinkedInIcon, PhoneIcon } from './icons/ContactIcons';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 border-t border-slate-800">
      <div className="container mx-auto px-6 md:px-12 lg:px-24 py-12">
        <div className="grid md:grid-cols-3 gap-8 text-center md:text-left">
            <div>
                <h3 className="text-xl font-bold text-slate-100">{PERSONAL_INFO.name}</h3>
                <p className="text-slate-400 mt-2 text-sm">{PERSONAL_INFO.title}</p>
            </div>
             <div>
                <h3 className="text-lg font-semibold text-slate-200 mb-4">Quick Links</h3>
                <ul className="space-y-2">
                    <li><a href="#about" className="text-slate-400 hover:text-cyan-400 text-sm">About</a></li>
                    <li><a href="#projects" className="text-slate-400 hover:text-cyan-400 text-sm">Projects</a></li>
                    <li><a href="#experience" className="text-slate-400 hover:text-cyan-400 text-sm">Experience</a></li>
                </ul>
            </div>
            <div>
                 <h3 className="text-lg font-semibold text-slate-200 mb-4">Get In Touch</h3>
                <div className="flex justify-center md:justify-start items-center gap-6">
                  <a href={`mailto:${PERSONAL_INFO.contact.email}`} className="text-slate-400 hover:text-cyan-400 transition-transform duration-300 hover:scale-110" aria-label="Email">
                    <MailIcon className="w-6 h-6" />
                  </a>
                  <a href={PERSONAL_INFO.contact.linkedin} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-cyan-400 transition-transform duration-300 hover:scale-110" aria-label="LinkedIn">
                    <LinkedInIcon className="w-6 h-6" />
                  </a>
                  <a href={`tel:${PERSONAL_INFO.contact.phone}`} className="text-slate-400 hover:text-cyan-400 transition-transform duration-300 hover:scale-110" aria-label="Phone">
                    <PhoneIcon className="w-6 h-6" />
                  </a>
                </div>
            </div>
        </div>
        <div className="border-t border-slate-800 mt-12 pt-8 text-center">
            <p className="text-slate-500 text-sm">
              &copy; {new Date().getFullYear()} Yashwanth Kumar T S. All Rights Reserved.
            </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;