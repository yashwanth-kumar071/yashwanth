import React from 'react';
import { SKILLS } from '../constants';
import SectionHeader from './SectionHeader';

const SkillCard: React.FC<{ name: string }> = ({ name }) => (
    <div className="bg-slate-800 rounded-lg p-4 text-center text-slate-300 font-medium transition-transform duration-300 hover:-translate-y-1 shadow-md hover:shadow-lg">
        {name}
    </div>
);

const Skills: React.FC = () => {
  const categories = [...new Set(SKILLS.map(skill => skill.category))];

  return (
    <div className="container mx-auto px-6 md:px-12 lg:px-24 opacity-0 animate-fade-in-up">
      <SectionHeader title="My Skills" />
      <div className="space-y-12">
        {categories.map(category => (
          <div key={category}>
            <h3 className="text-2xl font-semibold text-cyan-400 mb-6 text-center md:text-left">{category}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {SKILLS.filter(skill => skill.category === category).map(skill => (
                <SkillCard key={skill.name} name={skill.name} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Skills;