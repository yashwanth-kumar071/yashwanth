import React from 'react';
import { PROJECTS } from '../constants';
import SectionHeader from './SectionHeader';
import type { Project } from '../types';
import { ArrowRightIcon } from './icons/ArrowRightIcon';

const ProjectCard: React.FC<{ project: Project }> = ({ project }) => (
  <div className="bg-slate-800 rounded-lg p-6 flex flex-col h-full transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 border border-slate-700 hover:border-cyan-400">
    <div className="flex justify-between items-start mb-4">
      <h3 className="text-xl font-bold text-slate-100">{project.title}</h3>
      <span className="text-xs font-mono text-cyan-400">{project.date}</span>
    </div>
    <ul className="text-slate-400 space-y-2 list-none mb-6 flex-grow">
      {project.description.map((desc, i) => (
         <li key={i} className="flex items-start">
            <ArrowRightIcon className="w-4 h-4 text-cyan-400 mt-1 mr-2 flex-shrink-0" />
            <span>{desc}</span>
        </li>
      ))}
    </ul>
    <div className="mt-auto pt-4 border-t border-slate-700/50 flex flex-wrap gap-2">
      {project.tech.map(tech => (
        <span key={tech} className="bg-slate-700 text-cyan-300 text-xs font-medium px-2.5 py-1 rounded-full">
          {tech}
        </span>
      ))}
    </div>
  </div>
);

const Projects: React.FC = () => {
  return (
    <div className="container mx-auto px-6 md:px-12 lg:px-24 opacity-0 animate-fade-in-up">
      <SectionHeader title="Projects" />
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {PROJECTS.map(project => (
          <ProjectCard key={project.title} project={project} />
        ))}
      </div>
    </div>
  );
};

export default Projects;