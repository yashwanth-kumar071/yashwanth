import React from 'react';
import { TIMELINE } from '../constants';
import SectionHeader from './SectionHeader';
import type { TimelineEvent } from '../types';

const EducationIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path d="M12 14l9-5-9-5-9 5 9 5z" />
        <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-5.998 12.078 12.078 0 01.665-6.479L12 14z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5zm0 0v6" />
    </svg>
);

const WorkIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
    </svg>
);


const TimelineItem: React.FC<{ event: TimelineEvent }> = ({ event }) => {
  const Icon = event.type === 'education' ? EducationIcon : WorkIcon;

  return (
    <div className="relative pl-12 pb-12">
        <div className="absolute left-0 top-0 z-10 flex items-center justify-center w-8 h-8 rounded-full bg-slate-800 border-2 border-cyan-400 -translate-x-4">
             <Icon className="w-4 h-4 text-cyan-400" />
        </div>
      <div className="p-6 rounded-lg bg-slate-800/80 backdrop-blur-sm shadow-xl border border-slate-700">
        <p className="text-sm text-cyan-400 font-semibold mb-1">{event.date}</p>
        <h3 className="text-lg font-bold text-slate-100">{event.title}</h3>
        <p className="text-md font-medium text-slate-300">{event.subtitle}</p>
        <p className="text-sm text-slate-400 mt-2">{event.description}</p>
      </div>
    </div>
  );
};

const Experience: React.FC = () => {
  return (
    <div className="container mx-auto px-6 md:px-12 lg:px-24 opacity-0 animate-fade-in-up">
      <SectionHeader title="Experience & Education" />
      <div className="relative max-w-2xl mx-auto">
        <div className="absolute top-0 left-0 w-0.5 h-full bg-slate-700 -translate-x-4"></div>
        {TIMELINE.map((event, index) => (
          <TimelineItem key={index} event={event} />
        ))}
      </div>
    </div>
  );
};

export default Experience;