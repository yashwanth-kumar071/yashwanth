import React from 'react';
import { PERSONAL_INFO } from '../constants';
import SectionHeader from './SectionHeader';

const About: React.FC = () => {
  return (
    <div className="container mx-auto px-6 md:px-12 lg:px-24 opacity-0 animate-fade-in-up">
      <SectionHeader title="About Me" />
      <div className="grid md:grid-cols-5 gap-12 items-center">
          <div className="md:col-span-2">
            <img 
              src="https://picsum.photos/seed/yashwanth/400/400" 
              alt="Yashwanth Kumar TS" 
              className="rounded-lg w-full h-auto object-cover shadow-2xl"
            />
          </div>
          <div className="md:col-span-3">
            <p className="text-lg text-slate-300 leading-relaxed">
                {PERSONAL_INFO.objective}
            </p>
          </div>
      </div>
    </div>
  );
};

export default About;